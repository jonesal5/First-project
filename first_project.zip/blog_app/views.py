from django.shortcuts import render, HttpResponse 

def index(request):
    return HttpResponse("My Django Project")





# def index(request):
    # return render(request, 'index.html')
